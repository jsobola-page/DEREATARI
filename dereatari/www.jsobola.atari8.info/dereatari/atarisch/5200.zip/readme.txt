Zestaw schemat�w Atari 5200

1. 5200_ax.gif - trzycz�ciowy schemat 4-port Atari 5200 z p�yt� CA018087 (pierwsza wersja 5200, najstarsza).
2. 5200_bx.gif - trzycz�ciowy schemat 4-port Atari 5200 z p�yt� CA020108 (kolejna wersja 5200,
   dostosowana do wsp�pracy z interfejsem 2600).
3. 5200_cx.gif - trzycz�ciowy schemat 2-port Atari 5200 z p�yt� CA021374. 
4. trkballx.gif - dwucz�ciowy schemat trakballa do Atari 5200.
5. rfswitch.gif - schemat modu�u-przej�ci�wki do zasilania 4-port Atari 5200.
6. 5200acc.gif - schemat manipulatora do Atari 5200.
7. 2600intx.gif - dwucz�ciowy schemat interfejsu do pod��czenia kartrid�y z Atari  2600.
8. pitfall2.gif - schemat typowego kartrid�a - tu z gr� Pitfall II Lost Caverns.
9. vanguard.gif - schemat kartrid�a 20kB - tu z gr� Vanguard.