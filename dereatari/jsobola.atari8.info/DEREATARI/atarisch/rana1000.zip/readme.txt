Pliki rana_1a.gif, rana_2a.gif i rana_3a.gif to schemat stacji Rana 1000 z procesorem 6502.
Pliki rana_1b.gif i rana_2b.gif to schemat stacji Rana 1000 z procesorem 8031.

Odpowiednio opisane s� te� pliki ROM tych stacji: rana6502.bin i rana8031.bin.
