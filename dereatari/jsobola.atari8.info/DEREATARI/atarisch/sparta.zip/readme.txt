Sa tu dwa schematy kartridzy i dwa rodzaje EPROM-ow. Schemat pokazany w pliku 
SDX1.PCX sporzadzilem z natury - z jakiejs plytki opisanej Sparta Dos. Jedna 
taka trafila w moje rece w stanie dziewiczym, bez wmontowanych elementow. 
Dlugo trwalo, zanim ja rozgryzlem. Zmontowalem i... nie dziala. Ale dopiero 
teraz, gdy zebralem te materialy do kupy, zauwazylem, ze zawartosc epromow 
jest rozna. Jeszcze poprobuje. Drugi schemat pokazuje kartridz z GAL-em. Trzeba
tylko napisac plik zrodlowy GAL-a, skompilowac i zaprogramowac. Tylko... nie 
mam serca do Sparty :-((
Zycze   powodzenia
Jer

08 VI 2002:
Teraz jest OK. Plik sdxatrax.pcx/gif i sdxatrax.epr to opis tego kartridza.
Jer