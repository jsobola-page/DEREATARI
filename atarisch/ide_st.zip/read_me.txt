Uklad mozna zmontowac na plytce uniwersalnej. Sygnal ROM2 jest dostepny
w STE na pinie 9 ukladu U400 (C300589-001), w ST na pin 19 GLUE (CO25912).
Ukad dziala jedynie z TOSem wersji 2.06
Pliki z rozszerzeniem *.epr zawieraja  TOS 2.06 do zaprogramowania w epromach
27C010.
Plik idest.jed zawiera plik do zaprogramowania GAL 20V8.